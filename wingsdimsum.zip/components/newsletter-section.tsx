"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Mail, Gift, CheckCircle } from "lucide-react"
import { AnimatedSection } from "@/components/animated-section"

export default function NewsletterSection() {
  const [email, setEmail] = useState("")
  const [isSubscribed, setIsSubscribed] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))

    setIsSubscribed(true)
    setEmail("")
    setIsLoading(false)
  }

  return (
    <section className="py-20 bg-red-600 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-20 w-20 h-20 bg-white/10 rounded-full animate-float"></div>
        <div
          className="absolute bottom-20 right-20 w-16 h-16 bg-white/10 rounded-full animate-float"
          style={{ animationDelay: "1s" }}
        ></div>
        <div
          className="absolute top-1/2 left-10 w-12 h-12 bg-white/10 rounded-full animate-float"
          style={{ animationDelay: "2s" }}
        ></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <AnimatedSection animation="scale-in">
            <div className="flex justify-center mb-6">
              <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center hover-scale hover:bg-red-50 transition-all duration-300 group">
                <Gift className="w-8 h-8 text-red-600 group-hover:rotate-12 transition-transform duration-300" />
              </div>
            </div>
          </AnimatedSection>

          <AnimatedSection animation="fade-up" delay={200}>
            <h2 className="text-4xl font-bold text-white mb-4 hover:scale-105 transition-transform duration-300 cursor-default">
              Get 15% Off Your First Order
            </h2>
            <p className="text-xl text-red-100 mb-8 max-w-2xl mx-auto hover:text-white transition-colors">
              Subscribe to our newsletter and be the first to know about new dim sum creations, special offers, and
              exclusive recipes from our kitchen.
            </p>
          </AnimatedSection>

          <AnimatedSection animation="fade-up" delay={400}>
            {!isSubscribed ? (
              <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
                <div className="flex-1 relative group">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5 group-focus-within:text-red-600 transition-colors" />
                  <Input
                    type="email"
                    placeholder="Enter your email address"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-10 bg-white border-0 h-12 focus:shadow-lg transition-all duration-300"
                    required
                    disabled={isLoading}
                  />
                </div>
                <Button
                  type="submit"
                  size="lg"
                  className="bg-white text-red-600 hover:bg-gray-100 h-12 px-8 btn-animated hover-lift disabled:opacity-50"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <div className="w-4 h-4 border-2 border-red-600 border-t-transparent rounded-full animate-spin mr-2"></div>
                      Subscribing...
                    </>
                  ) : (
                    "Subscribe"
                  )}
                </Button>
              </form>
            ) : (
              <div className="bg-white rounded-lg p-6 max-w-md mx-auto animate-scale-in hover-lift">
                <div className="text-green-600 text-4xl mb-4 animate-bounce-in">
                  <CheckCircle className="w-12 h-12 mx-auto" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Welcome to the family!</h3>
                <p className="text-gray-600">Check your email for your 15% discount code.</p>
              </div>
            )}
          </AnimatedSection>

          <AnimatedSection animation="fade-up" delay={600}>
            <p className="text-red-100 text-sm mt-6 hover:text-white transition-colors">
              No spam, unsubscribe at any time. By subscribing, you agree to our privacy policy.
            </p>
          </AnimatedSection>
        </div>
      </div>
    </section>
  )
}
