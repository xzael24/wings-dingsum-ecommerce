"use client"

import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ArrowRight, Star, Play } from "lucide-react"
import { AnimatedSection } from "@/components/animated-section"
import { AnimatedCounter } from "@/components/animated-counter"
import { useState } from "react"

export default function HeroSection() {
  const [isVideoPlaying, setIsVideoPlaying] = useState(false)

  return (
    <section className="relative bg-gradient-to-r from-red-50 to-red-100 py-20 overflow-hidden">
      {/* Floating background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-20 h-20 bg-red-200 rounded-full opacity-20 animate-float"></div>
        <div
          className="absolute top-40 right-20 w-16 h-16 bg-red-300 rounded-full opacity-30 animate-float"
          style={{ animationDelay: "1s" }}
        ></div>
        <div
          className="absolute bottom-20 left-1/4 w-12 h-12 bg-red-400 rounded-full opacity-25 animate-float"
          style={{ animationDelay: "2s" }}
        ></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <AnimatedSection animation="fade-up" delay={200}>
              <div className="space-y-4">
                <div className="flex items-center space-x-2 group">
                  <div className="flex text-yellow-400 group-hover:scale-110 transition-transform duration-300">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className="w-5 h-5 fill-current animate-pulse"
                        style={{ animationDelay: `${i * 0.1}s` }}
                      />
                    ))}
                  </div>
                  <span className="text-gray-600 hover:text-red-600 transition-colors cursor-default">
                    Rated 4.9/5 by customers
                  </span>
                </div>

                <h1 className="text-4xl lg:text-6xl font-bold text-gray-900 leading-tight">
                  <span className="inline-block hover:text-red-600 transition-colors duration-300">Premium</span>{" "}
                  <span className="text-red-600 inline-block hover:scale-105 transition-transform duration-300 cursor-default">
                    Mentai Tobiko
                  </span>{" "}
                  <span className="inline-block hover:text-red-600 transition-colors duration-300">Dim Sum</span>
                </h1>

                <p className="text-xl text-gray-600 leading-relaxed hover:text-gray-800 transition-colors duration-300">
                  Experience the perfect fusion of traditional dim sum craftsmanship with premium Japanese ingredients.
                  Our signature mentai and tobiko create an unforgettable burst of umami flavors.
                </p>
              </div>
            </AnimatedSection>

            <AnimatedSection animation="fade-up" delay={400}>
              <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
                <Button
                  asChild
                  size="lg"
                  className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 text-sm sm:text-base btn-animated hover-lift hover-glow group"
                >
                  <Link href="/products">
                    Order Now
                    <ArrowRight className="ml-2 w-4 h-4 sm:w-5 sm:h-5 group-hover:translate-x-1 transition-transform duration-300" />
                  </Link>
                </Button>
                <Button
                  asChild
                  variant="outline"
                  size="lg"
                  className="border-red-600 text-red-600 hover:bg-red-50 px-6 py-3 text-sm sm:text-base hover-lift group"
                >
                  <Link href="/about">
                    Learn More
                    <span className="ml-2 group-hover:scale-110 transition-transform duration-300">→</span>
                  </Link>
                </Button>
              </div>
            </AnimatedSection>

            <AnimatedSection animation="fade-up" delay={600}>
              <div className="grid grid-cols-3 gap-8 pt-8">
                <div className="text-center group hover-scale cursor-default">
                  <div className="text-3xl font-bold text-red-600 group-hover:text-red-700 transition-colors">
                    <AnimatedCounter end={50} suffix="+" />
                  </div>
                  <div className="text-gray-600 group-hover:text-gray-800 transition-colors">Dim Sum Varieties</div>
                </div>
                <div className="text-center group hover-scale cursor-default">
                  <div className="text-3xl font-bold text-red-600 group-hover:text-red-700 transition-colors">
                    <AnimatedCounter end={10} suffix="k+" />
                  </div>
                  <div className="text-gray-600 group-hover:text-gray-800 transition-colors">Happy Customers</div>
                </div>
                <div className="text-center group hover-scale cursor-default">
                  <div className="text-3xl font-bold text-red-600 group-hover:text-red-700 transition-colors">
                    <AnimatedCounter end={5} suffix="★" />
                  </div>
                  <div className="text-gray-600 group-hover:text-gray-800 transition-colors">Average Rating</div>
                </div>
              </div>
            </AnimatedSection>
          </div>

          <AnimatedSection animation="fade-left" delay={300}>
            <div className="relative group">
              <div className="relative z-10">
                <div className="relative overflow-hidden rounded-2xl shadow-2xl hover-lift">
                  <Image
                    src="/images/hero-dimsum.png"
                    alt="Premium Mentai Tobiko Dim Sum"
                    width={600}
                    height={600}
                    className="rounded-2xl transition-transform duration-700 group-hover:scale-105"
                    priority
                  />

                  {/* Play button overlay */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-black bg-opacity-20 rounded-2xl">
                    <button
                      onClick={() => setIsVideoPlaying(true)}
                      className="w-16 h-16 bg-white bg-opacity-90 rounded-full flex items-center justify-center hover:bg-opacity-100 transition-all duration-300 hover:scale-110"
                    >
                      <Play className="w-6 h-6 text-red-600 ml-1" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Animated background shapes */}
              <div className="absolute -top-4 -right-4 w-full h-full bg-red-200 rounded-2xl -z-10 group-hover:rotate-3 transition-transform duration-500"></div>
              <div className="absolute -bottom-4 -left-4 w-full h-full bg-red-100 rounded-2xl -z-20 group-hover:-rotate-2 transition-transform duration-500"></div>

              {/* Floating badges */}
              <div className="absolute top-4 left-4 bg-white rounded-full p-3 shadow-lg animate-bounce-in hover-rotate z-20">
                <span className="text-red-600 font-bold text-sm">Fresh Daily</span>
              </div>
              <div
                className="absolute bottom-4 right-4 bg-red-600 text-white rounded-full p-3 shadow-lg animate-bounce-in hover-rotate z-20"
                style={{ animationDelay: "0.5s" }}
              >
                <span className="font-bold text-sm">Premium</span>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </div>
    </section>
  )
}
