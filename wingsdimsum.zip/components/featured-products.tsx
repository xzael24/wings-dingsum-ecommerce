"use client"

import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star, Plus, Heart } from "lucide-react"
import { AnimatedSection } from "@/components/animated-section"
import { useCart } from "@/contexts/cart-context"
import { useState } from "react"
import { useToast } from "@/hooks/use-toast"

const featuredProducts = [
  {
    id: 1,
    name: "Signature Mentai Shumai",
    description: "Delicate pork and shrimp shumai topped with premium mentai sauce",
    price: 18.99,
    originalPrice: 22.99,
    image: "/images/mentai-shumai.jpg",
    rating: 4.9,
    reviews: 127,
    badge: "Best Seller",
    ingredients: ["Premium Mentai", "Fresh Shrimp", "Pork", "Wonton Wrapper"],
  },
  {
    id: 2,
    name: "Tobiko Har Gow",
    description: "Crystal shrimp dumplings with bursting tobiko pearls",
    price: 16.99,
    originalPrice: null,
    image: "/images/tobiko-hargow.jpg",
    rating: 4.8,
    reviews: 89,
    badge: "New",
    ingredients: ["Flying Fish Roe", "Fresh Shrimp", "Crystal Wrapper"],
  },
  {
    id: 3,
    name: "Mentai Tobiko Bao",
    description: "Fluffy steamed buns filled with mentai tobiko mixture",
    price: 14.99,
    originalPrice: 17.99,
    image: "/images/mentai-bao.jpg",
    rating: 4.7,
    reviews: 156,
    badge: "Popular",
    ingredients: ["Mentai", "Tobiko", "Steamed Bun", "Special Sauce"],
  },
  {
    id: 4,
    name: "Dragon Roll Dumpling",
    description: "Fusion dumpling with mentai, tobiko, and avocado",
    price: 19.99,
    originalPrice: null,
    image: "/images/dragon-roll-dumpling.jpg",
    rating: 4.9,
    reviews: 203,
    badge: "Chef's Special",
    ingredients: ["Premium Mentai", "Tobiko", "Avocado", "Nori"],
  },
]

export default function FeaturedProducts() {
  const { addItem } = useCart()
  const { toast } = useToast()
  const [favorites, setFavorites] = useState<number[]>([])
  const [addingToCart, setAddingToCart] = useState<number | null>(null)

  const toggleFavorite = (id: number) => {
    setFavorites((prev) => (prev.includes(id) ? prev.filter((fav) => fav !== id) : [...prev, id]))
  }

  const handleAddToCart = async (product: (typeof featuredProducts)[0]) => {
    setAddingToCart(product.id)

    // Simulate loading
    await new Promise((resolve) => setTimeout(resolve, 500))

    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
    })

    toast({
      title: "Added to Cart!",
      description: `${product.name} has been added to your cart.`,
    })

    setAddingToCart(null)
  }

  return (
    <section className="py-20 bg-white relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-red-50/30 to-transparent"></div>

      <div className="container mx-auto px-4 relative z-10">
        <AnimatedSection animation="fade-up" className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Featured <span className="text-red-600 hover:text-red-700 transition-colors cursor-default">Dim Sum</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto hover:text-gray-800 transition-colors">
            Discover our most popular creations featuring premium mentai and tobiko ingredients
          </p>
        </AnimatedSection>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {featuredProducts.map((product, index) => (
            <AnimatedSection key={product.id} animation="scale-in" delay={index * 100} className="h-full">
              <Card className="group hover:shadow-xl transition-all duration-500 border-0 shadow-lg hover-lift h-full flex flex-col relative overflow-hidden">
                {/* Shimmer effect on hover */}
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000 pointer-events-none"></div>

                <CardHeader className="p-0 relative">
                  <div className="relative overflow-hidden rounded-t-lg image-zoom">
                    <Image
                      src={product.image || "/placeholder.svg"}
                      alt={product.name}
                      width={300}
                      height={300}
                      className="w-full h-64 object-cover transition-transform duration-700"
                    />

                    {product.badge && (
                      <Badge className="absolute top-4 left-4 bg-red-600 text-white animate-pulse-slow">
                        {product.badge}
                      </Badge>
                    )}

                    {/* Favorite button */}
                    <Button
                      variant="ghost"
                      size="icon"
                      className="absolute top-4 right-4 bg-white/80 hover:bg-white transition-all duration-300 hover:scale-110"
                      onClick={() => toggleFavorite(product.id)}
                    >
                      <Heart
                        className={`w-4 h-4 transition-all duration-300 ${
                          favorites.includes(product.id)
                            ? "fill-red-500 text-red-500 scale-110"
                            : "text-gray-600 hover:text-red-500"
                        }`}
                      />
                    </Button>

                    {/* Rating badge */}
                    <div className="absolute bottom-4 right-4 bg-white rounded-full p-2 shadow-md hover:shadow-lg transition-shadow duration-300">
                      <div className="flex items-center space-x-1">
                        <Star className="w-4 h-4 text-yellow-400 fill-current" />
                        <span className="text-sm font-medium">{product.rating}</span>
                      </div>
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="p-6 flex-grow">
                  <CardTitle className="text-xl mb-2 group-hover:text-red-600 transition-colors duration-300 cursor-default">
                    {product.name}
                  </CardTitle>
                  <p className="text-gray-600 mb-4 text-sm leading-relaxed group-hover:text-gray-800 transition-colors">
                    {product.description}
                  </p>

                  <div className="mb-4">
                    <div className="flex flex-wrap gap-1">
                      {product.ingredients.map((ingredient, index) => (
                        <Badge
                          key={index}
                          variant="secondary"
                          className="text-xs hover:bg-red-100 hover:text-red-700 transition-colors cursor-default"
                        >
                          {ingredient}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-2">
                      <span className="text-2xl font-bold text-red-600 hover:text-red-700 transition-colors">
                        ${product.price}
                      </span>
                      {product.originalPrice && (
                        <span className="text-lg text-gray-400 line-through">${product.originalPrice}</span>
                      )}
                    </div>
                    <div className="text-sm text-gray-500 hover:text-gray-700 transition-colors cursor-default">
                      ({product.reviews} reviews)
                    </div>
                  </div>
                </CardContent>

                <CardFooter className="p-4 sm:p-6 pt-0">
                  <Button
                    className="w-full bg-red-600 hover:bg-red-700 text-white py-2 sm:py-3 text-sm sm:text-base btn-animated hover-lift disabled:opacity-50 disabled:cursor-not-allowed"
                    onClick={() => handleAddToCart(product)}
                    disabled={addingToCart === product.id}
                  >
                    {addingToCart === product.id ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                        Adding...
                      </>
                    ) : (
                      <>
                        <Plus className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2 group-hover:rotate-90 transition-transform duration-300" />
                        Add to Cart
                      </>
                    )}
                  </Button>
                </CardFooter>
              </Card>
            </AnimatedSection>
          ))}
        </div>

        <AnimatedSection animation="fade-up" delay={400} className="text-center mt-8 sm:mt-12">
          <Button
            asChild
            variant="outline"
            size="lg"
            className="border-red-600 text-red-600 hover:bg-red-50 px-6 py-3 text-sm sm:text-base hover-lift btn-animated group"
          >
            <Link href="/products">
              View All Products
              <span className="ml-2 group-hover:translate-x-1 transition-transform duration-300">→</span>
            </Link>
          </Button>
        </AnimatedSection>
      </div>
    </section>
  )
}
