"use client"

export default function CheckoutPageClient() {
  return <div>Checkout Page Client</div>
}
